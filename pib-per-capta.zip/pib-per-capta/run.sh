#!/bin/bash
python3.7 script-pib-client.py